const router = require("express").Router();
const ctrl = require("../controllers/dashboardController");
const auth = require("../middlewares/auth");
const role = require("../middlewares/role");

router.get("/summary", auth, role("admin", "analyst"), ctrl.getSummary);
router.get("/category", auth, role("admin", "analyst"), ctrl.categoryWise);

module.exports = router;