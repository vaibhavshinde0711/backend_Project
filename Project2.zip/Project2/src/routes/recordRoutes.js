const router = require("express").Router();
const ctrl = require("../controllers/recordController");
const auth = require("../middlewares/auth");
const role = require("../middlewares/role");

router.post("/", auth, role("admin"), ctrl.createRecord);
router.get("/", auth, role("admin", "analyst", "viewer"), ctrl.getRecords);
router.put("/:id", auth, role("admin"), ctrl.updateRecord);
router.delete("/:id", auth, role("admin"), ctrl.deleteRecord);

module.exports = router;